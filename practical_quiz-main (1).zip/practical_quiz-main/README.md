<h1>Practical Quiz</h1>
> Collaborate with your group members and accomplish the task as one.<br>
> The goal is to test your practical skills in building static website from scratch

<h3>Quick Notes</h3>
> Download the the starter file as your boilerplate <br>
> Open the style/site.css, and read carefully each comments, which most of the tasks are identenfied in completing the quiz<br>

<h3>Screenshot</h3>
<img src="screenshot/harvard-extension-explore-studentsuccess.png" alt="Finished Website">
